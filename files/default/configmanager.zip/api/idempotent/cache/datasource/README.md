This directory holds datasource configuration hashes.
